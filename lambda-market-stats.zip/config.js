// Please set the configuration below
module.exports = {
  screeps: {
    username: 'ags131',
    password: 'KgDUyegIkMbM9Arq'
  },
  influxdb: {
    url: 'http://163.172.183.243:8086',
    database: 'market',
    auth: {
      user: 'ags131',
      pass: 'cardman93'
    }
  }
}
